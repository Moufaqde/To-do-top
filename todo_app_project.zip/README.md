# Einfache Aufgabenliste (To-Do App)

Dies ist ein einfaches Webprojekt zum Verwalten einer Aufgabenliste. Es wurde mit HTML, CSS und JavaScript erstellt.

## Funktionen
- Neue Aufgaben hinzufügen
- Aufgaben durch Klicken entfernen
- Minimalistisches Design
- Keine externen Bibliotheken notwendig

## Verwendung
Öffne einfach `index.html` in deinem Browser.

## Autor
Mouafaq Alboni
